#https://www.codechef.com/problems/FLOW018
#Chintan Patel 24-12-2016

import math
T = input()
while T>0:
	print math.factorial(input())
	T -= 1