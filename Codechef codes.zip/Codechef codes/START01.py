#https://www.codechef.com/problems/START01
#Chintan Patel 24-12-2016

print input()