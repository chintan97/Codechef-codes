#https://www.codechef.com/problems/FCTRL2
#Chintan Patel 3-1-2016

import math
T = input()
while T:
	print math.factorial(input())
	T -= 1