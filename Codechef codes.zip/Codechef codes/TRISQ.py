#https://www.codechef.com/problems/TRISQ
#Chintan Patel 24-12-2016

T = input()
while T>0:
	B = input()
	print ((B/2)*(B/2-1))/2
	T -= 1