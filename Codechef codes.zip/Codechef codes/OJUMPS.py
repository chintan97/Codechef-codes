#https://www.codechef.com/problems/OJUMPS
#Chintan Patel 30-12-2016

a = input()
if a%6 == 0 or a%6 == 1 or a%6 == 3: print 'yes'
else: print 'no'