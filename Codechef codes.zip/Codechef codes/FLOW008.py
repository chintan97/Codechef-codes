#https://www.codechef.com/problems/FLOW008
#Chintan Patel 24-12-2016

T = input()
while T>0:
	if input() < 10: print 'What an obedient servant you are!'
	else: print '-1'
	T -= 1