#https://www.codechef.com/problems/ANUWTA
#Chintan Patel 31-12-2016

T = input()
while T:
	N = input()
	print N+((N*(N+1))/2)
	T -= 1