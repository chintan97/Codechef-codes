#https://www.codechef.com/problems/FSQRT
#Chintan Patel 24-12-2016

import math
T = input()
while T>0:
	print int(math.sqrt(input()))
	T -= 1