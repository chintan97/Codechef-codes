#https://www.codechef.com/problems/LUCKFOUR
#Chintan Patel 24-12-2016

T = input()
while T>0:
	N = str(input())
	print N.count('4')
	T -= 1